Require Import Reals.

Open Scope R_scope.

Definition gamma_phi : R := (sqrt 5 - 2).
Definition dl_lower : R := (ln 2 / PI).
Definition dl_upper : R := (ln 3 / PI).

(* Helper lemma: numeric bounds for gamma_phi *)
Lemma gamma_phi_approx : 0.236 < sqrt 5 - 2 < 0.237.
Proof.
  unfold gamma_phi.
  vm_compute.
Qed.

Theorem gamma_phi_within_dl_bounds : dl_lower < gamma_phi < dl_upper.
Proof.
  unfold dl_lower, dl_upper, gamma_phi.
  (* Use computed bounds from gamma_phi_approx lemma *)
  assert (H1 : dl_lower < gamma_phi).
  { apply gamma_phi_approx. assumption. }
  assert (H2 : gamma_phi < dl_upper).
  { apply gamma_phi_approx. assumption. }
Qed.
