# Fibonacci unit tests: S1-S6
# Tests Fibonacci identities with φ

invariant test_phi_fibonacci:
  spec physics/phi_fibonacci.t27
  test S1_phi_fibonacci
  result | pass | Δ% |
  # S1 formula: φ² = φ + 1 |
  # γ_φ in φ³ = φ⁻³ |
