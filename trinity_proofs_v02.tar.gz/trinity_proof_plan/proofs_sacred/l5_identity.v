Require Import Reals.

Open Scope R_scope.

Definition phi : R := ((1 + sqrt 5) / 2).

Theorem trinity_identity : phi ^ 2 + (1 / phi) ^ 2 = 3.
Proof.
  unfold phi.
  (* Phi identity: (1+sqrt5)^2 = 1 + 2*sqrt5 + 5 = 6 + 2*sqrt5 *)
  (* Note: This is computed, not derived *)
  vm_compute.
Qed.
