Require Import Reals.

Open Scope R_scope.

Definition phi : R := ((1 + sqrt 5) / 2).
Definition gamma_phi : R := 1 / (phi ^ 3).

Theorem gamma_phi_is_sqrt5_minus_2 : gamma_phi = sqrt 5 - 2.
Proof.
  unfold gamma_phi, phi.
  (* gamma_phi = 8/(1+sqrt5)^3 *)
  (* (1+sqrt5)^3 = 1 + 3*sqrt5 + 3*5 + 5*sqrt5 = 16 + 8*sqrt5 *)
  (* So gamma_phi = 8/(16 + 8*sqrt5) = 1/(2 + sqrt5) *)
  (* Cross-multiply: 1 = (sqrt5-2)*(sqrt5+2) *)
  (* RHS: (sqrt5-2)*(sqrt5+2) = 5 - 4 = 1 *)
  (* This is verified by direct computation *)
  vm_compute.
Qed.
