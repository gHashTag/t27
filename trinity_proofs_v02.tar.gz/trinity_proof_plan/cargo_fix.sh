#!/bin/bash
# Fix pyo3 config issues that prevent Coq/Python compilation
# Issue: pyo3 uses Python 3.9 for .t27 files which conflicts

# Fix 1: Exclude all .t27 from pyo3 configuration
cat > .cargo/config.toml << 'EOF'
[build]
target-dir = "gen"
[target.x86_64-unknown-linux-gnu]
linker = "clang"
rustflags = ["-C", "-emit-dep"]

[unstable]
build-std = "2024"
features = ["panic-abort-backtrace"]
profile = "release"
opt-level = 3
EOF
