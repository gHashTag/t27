#!/bin/bash
# Git workflow: 5 commits + GitHub PR
# Each commit corresponds to a distinct task in the plan

set -e

# Commit 1: Create 152-formula verification script
git commit -m "feat: add verify_all_152.py script for Trinity γ-paper (v0.2)

# Commit 2: Create Coq proof directory structure
git commit -m "feat: add proofs/ directory with L5 Trinity, gamma_phi, DL bounds"

# Commit 3: Add particle physics spec skeletons
git commit -m "feat: add specs_physics/ skeletons (ckm, electroweak, pmns, phi_fibonacci, gamma_conflict)"

# Commit 4: Add cargo/pyo3 fix
git commit -m "fix: exclude .t27 from pyo3 configuration"

# Commit 5: Create git automation scripts
git commit -m "chore: add git_commands.sh and cargo_fix.sh"

# Create PR after all commits
git push origin master
gh pr create --title "Trinity γ-Paper Integration (v0.2): 152 Formulas, Coq Proofs" \
              --body "This PR implements Trinity γ-Paper v0.2 integration:
- ✅ 152-formula verification script with 50-digit precision
- ✅ Coq proof skeletons (L5, gamma_phi, DL bounds)
- ✅ Particle physics spec skeletons (4 test suites)
- ✅ PyO3 config fix for .t27 compatibility
- ✅ Git workflow automation

Associated issues: #0-# (will create)"

echo "5 commits prepared. Run: git push && gh pr create to complete integration."
